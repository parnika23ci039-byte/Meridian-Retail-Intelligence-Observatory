"""Auto-writes outputs/REPORT.md from the computed numbers so the report can never drift from the code."""
from .insights import cr, pv


def write_report(P, path):
    k, d, seg, fc, M = P["kpi"], P["discount"], P["segments"], P["forecast"], P["meta"]
    L = []
    a = L.append
    a("# Meridian - Retail Analytics & AI-Powered Sales Forecasting System\n")
    a(f"*Auto-generated {M['generated']} from `{M['source']}` ({M['rows']:,} rows, {M['dates'][0]} to {M['dates'][-1]}).*\n")
    a("## 1. Executive summary\n")
    for i in P["insights"]:
        a(f"- **{i['title']}.** {i['body']}")
    a("\n## 2. Data & quality\n")
    a("| Check | Status | Detail |\n|---|---|---|")
    for q in P["quality"]:
        a(f"| {q['name']} | {q['status'].upper()} | {q['detail']} |")
    a("\n## 3. Forecasting\n")
    t = fc["TOTAL"]
    a(f"Seven models were compared with a rolling-origin backtest (11 folds x 30 days). Champion for total revenue: **{t['champion_label']}**.\n")
    a("| Model | MAE (\u20b9 Cr/day) | MAPE | Skill vs long-run mean | Fold win-rate |\n|---|---|---|---|---|")
    for b in t["board"]:
        a(f"| {b['label']} | {b['mae'] / 1e7:.3f} | {b['mape']:.1f}% | {b['skill']:+.1%} | {b['win_rate']:.0%} |")
    dg = t["diag"]
    a(f"\nForecastability tests: Ljung-Box {pv(dg['ljung_box_p'])}, weekday ANOVA {pv(dg['weekday_p'])}, month ANOVA {pv(dg['month_p'])}, trend {pv(dg['trend_p'])} "
      f"-> structure score {dg['score']}/100 (*{dg['verdict']}*).\n")
    a("Next six months (80% interval from backtest residuals):\n")
    a("| Month | Forecast | 80% low | 80% high |\n|---|---|---|---|")
    for m in t["months"]:
        a(f"| {m['month']} | {cr(m['point'])} | {cr(m['lo80'])} | {cr(m['hi80'])} |")
    a("\n## 4. Store segmentation\n")
    a(f"KMeans on {len(seg['features'])} standardised behavioural features; k={seg['k']} chosen by silhouette ({seg['silhouette']:.2f}).\n")
    a("| Store | City | Archetype | Health | Revenue | YoY |\n|---|---|---|---|---|---|")
    for s in sorted(seg["stores"], key=lambda s: -s["health"]):
        a(f"| {s['id']} | {s['city']} | {s['archetype']} | {s['health']:.0f} | {cr(s['revenue'])} | {s['growth']:+.1%} |")
    a("\n## 5. Discount economics\n")
    a("| Discount | Transactions | Avg units | Avg ticket (\u20b9) |\n|---|---|---|---|")
    for r in d["levels"]:
        a(f"| {r['Discount_Percentage']:.0f}% | {r['txns']:,.0f} | {r['units']:.2f} | {r['ticket']:,.0f} |")
    a("\n## 6. Recommendations\n")
    a("1. Pilot a smaller discount ladder (cap at 10%) in two stores and measure units/basket; the history shows no volume reward for deeper cuts.")
    a("2. Add festival and promotion calendars to the data - the current Holiday_Flag covers only Oct-Dec and cannot support demand planning.")
    a("3. Fix the SKU master: Product_ID currently maps to multiple categories and brands.")
    a("4. Test basket-building offers for returning customers; ticket size is identical to new customers.")
    a("5. Re-run `python run.py` monthly. If seasonality emerges, the arena will automatically promote a seasonal model.")
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
