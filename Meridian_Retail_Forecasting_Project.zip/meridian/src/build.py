"""Orchestrates the whole pipeline: raw data -> analytics -> forecasts -> segments -> web/data.js + outputs/*."""
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import analytics as A, etl, forecasting as F, insights, segmentation as S
from .config import DEFAULT_DATA, OUT_DIR, WEB_DIR


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (float, np.floating)):
        o = float(o)
        if not np.isfinite(o):
            return None
        return int(round(o)) if abs(o) >= 1000 else round(o, 5)
    return o


def main(path=None):
    t0 = time.time()
    path = Path(path) if path else DEFAULT_DATA
    print(f"[1/6] Loading {path.name}")
    raw = etl.load(path)
    quality = etl.validate(raw)
    df = etl.enrich(raw)
    dates = [d.strftime("%Y-%m-%d") for d in pd.date_range(df.Date.min(), df.Date.max())]
    stores = sorted(df.Store_ID.unique())
    cats = sorted(df.Product_Category.unique())
    sub_map = df.drop_duplicates("Product_Subcategory").set_index("Product_Subcategory").Product_Category
    subs = sorted(sub_map.index, key=lambda s: (cats.index(sub_map[s]), s))
    months = sorted(df.YM.unique())

    print("[2/6] Building analytics cubes")
    dts = [pd.Timestamp(d) for d in dates]
    meta_stores = [{"id": s, "city": df[df.Store_ID == s].Store_Location.iat[0], "region": df[df.Store_ID == s].Region.iat[0]} for s in stores]
    dc = A.daily_cube(df, dts, stores, cats)
    mc = A.monthly_cube(df, months, stores, subs)
    k = A.kpis(df)
    disc, par, mix = A.discount_lab(df), A.pareto(df), A.static_mix(df)
    daily = df.groupby("Date").Revenue.sum()
    anoms = A.anomalies(daily)
    seas = A.seasonality_profiles(daily)

    print("[3/6] Segmenting stores")
    seg, feat = S.segment(df)

    print("[4/6] Forecast arena (14 series x 7 models x 11 folds)")
    series = {"TOTAL": daily}
    for c in cats:
        series["cat:" + c] = df[df.Product_Category == c].groupby("Date").Revenue.sum()
    for s in stores:
        series["store:" + s] = df[df.Store_ID == s].groupby("Date").Revenue.sum()
    fc = {}
    for i, (key, ser) in enumerate(series.items(), 1):
        fc[key] = F.run_arena(ser)
        print(f"      {i:>2}/{len(series)} {key:<22} champion = {fc[key]['champion_label']}")

    print("[5/6] Writing insights")
    story = insights.build(k, disc, par, mix, seg, fc["TOTAL"], quality, anoms, df)

    payload = {"meta": {"generated": datetime.now().strftime("%d %b %Y, %H:%M"), "source": path.name, "rows": int(len(df)),
                        "dates": dates, "stores": meta_stores, "cats": cats,
                        "subs": [{"name": s, "cat": cats.index(sub_map[s])} for s in subs], "months": months},
               "daily": dc, "monthly": mc, "kpi": k, "discount": disc, "pareto": par, "mix": mix, "seasonality": seas,
               "anomalies": anoms, "segments": seg, "forecast": fc, "insights": story, "quality": quality}
    print("[6/6] Exporting")
    WEB_DIR.mkdir(exist_ok=True)
    OUT_DIR.mkdir(exist_ok=True)
    js = "window.MERIDIAN = " + json.dumps(_clean(payload), separators=(",", ":")) + ";"
    (WEB_DIR / "data.js").write_text(js, encoding="utf-8")
    feat.drop(columns=["lat", "lon"]).round(4).to_csv(OUT_DIR / "store_segments.csv")
    rows = []
    for key, r in fc.items():
        for d, p, a, b in zip(r["forecast"]["date"], r["forecast"]["point"], r["forecast"]["lo80"], r["forecast"]["hi80"]):
            rows.append({"series": key, "date": d, "forecast": round(p), "lo80": round(a), "hi80": round(b), "model": r["champion_label"]})
    pd.DataFrame(rows).to_csv(OUT_DIR / "forecast_daily.csv", index=False)
    pd.DataFrame([{**b, "series": key} for key, r in fc.items() for b in r["board"]]).to_csv(OUT_DIR / "model_leaderboard.csv", index=False)
    pd.DataFrame(quality).to_csv(OUT_DIR / "data_quality_report.csv", index=False)
    from .report import write_report
    write_report(payload, OUT_DIR / "REPORT.md")
    print(f"Done in {time.time() - t0:.0f}s  ->  web/data.js ({len(js) / 1e6:.1f} MB), outputs/")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
