"""Descriptive + diagnostic analytics. Everything the dashboard needs is produced here."""
import numpy as np
import pandas as pd
from scipy import stats


def daily_cube(df, dates, stores, cats):
    """date x store x category cube (columnar) for client-side filtering."""
    g = df.groupby(["Date", "Store_ID", "Product_Category"]).agg(
        rev=("Revenue", "sum"), sales=("Total_Sales", "sum"), units=("Units_Sold", "sum"), n=("Revenue", "size")).reset_index()
    di = {d: i for i, d in enumerate(dates)}
    return {"d": [di[d] for d in g.Date], "s": [stores.index(s) for s in g.Store_ID], "c": [cats.index(c) for c in g.Product_Category],
            "rev": g.rev.round(0).astype(int).tolist(), "sales": g.sales.round(0).astype(int).tolist(),
            "units": g.units.tolist(), "n": g.n.tolist()}


def monthly_cube(df, months, stores, subs):
    """month x store x subcategory x customer x discount cube."""
    g = df.groupby(["YM", "Store_ID", "Product_Subcategory", "Customer_Type", "Discount_Percentage"]).agg(
        rev=("Revenue", "sum"), sales=("Total_Sales", "sum"), units=("Units_Sold", "sum"), n=("Revenue", "size")).reset_index()
    mi = {m: i for i, m in enumerate(months)}
    return {"m": [mi[m] for m in g.YM], "s": [stores.index(s) for s in g.Store_ID], "u": [subs.index(s) for s in g.Product_Subcategory],
            "k": [0 if c == "New" else 1 for c in g.Customer_Type], "x": (g.Discount_Percentage // 5).astype(int).tolist(),
            "rev": g.rev.round(0).astype(int).tolist(), "sales": g.sales.round(0).astype(int).tolist(),
            "units": g.units.tolist(), "n": g.n.tolist()}


def discount_lab(df) -> dict:
    g = df.groupby("Discount_Percentage").agg(txns=("Revenue", "size"), units=("Units_Sold", "mean"),
                                             gross=("Total_Sales", "sum"), net=("Revenue", "sum"), ticket=("Revenue", "mean")).reset_index()
    groups = [x.Units_Sold.values for _, x in df.groupby("Discount_Percentage")]
    p_anova = float(stats.f_oneway(*groups).pvalue)
    # log-linear elasticity: % change in units per +1pp discount
    reg = stats.linregress(df.Discount_Percentage, np.log(df.Units_Sold))
    ci = 1.96 * reg.stderr
    txn_per_level = g.txns.values
    chi_p = float(stats.chisquare(txn_per_level).pvalue)
    promo = df.groupby("Promotion_Applied").agg(units=("Units_Sold", "mean"), ticket=("Revenue", "mean"), disc=("Discount_Percentage", "mean"), n=("Revenue", "size"))
    p_promo = float(stats.ttest_ind(df[df.Promotion_Applied == "Yes"].Units_Sold, df[df.Promotion_Applied == "No"].Units_Sold).pvalue)
    leak = float(df.Discount_Amount.sum())
    return {"levels": g.round(2).to_dict("records"), "p_units_anova": p_anova, "p_txn_chi2": chi_p,
            "lift_per_pp": float(reg.slope), "lift_ci": float(ci), "lift_p": float(reg.pvalue),
            "leak": leak, "leak_share": leak / float(df.Total_Sales.sum()), "gross": float(df.Total_Sales.sum()),
            "net": float(df.Revenue.sum()), "avg_disc": float(df.Discount_Percentage.mean()),
            "promo": {k: {m: float(v) for m, v in r.items()} for k, r in promo.iterrows()}, "p_promo": p_promo}


def pareto(df) -> dict:
    p = df.groupby("Product_ID").Revenue.sum().sort_values(ascending=False).reset_index()
    cum = (p.Revenue.cumsum() / p.Revenue.sum()).values
    n = len(p)
    cls = np.where(cum <= 0.70, "A", np.where(cum <= 0.90, "B", "C"))
    return {"n": n, "curve": [round(float(cum[int(i * (n - 1) / 99)]), 4) for i in range(100)],
            "top20_share": float(cum[int(n * 0.2) - 1]), "abc": {k: int((cls == k).sum()) for k in "ABC"},
            "top": [{"id": r.Product_ID, "rev": float(r.Revenue)} for r in p.head(8).itertuples()],
            "gini": float(1 - 2 * np.trapezoid(np.r_[0, np.sort(p.Revenue.values)].cumsum() / p.Revenue.sum(), dx=1 / n))}


def static_mix(df) -> dict:
    out = {}
    for col, key in [("Payment_Mode", "payment"), ("Promotion_Applied", "promo"), ("Customer_Type", "customer"), ("Region", "region")]:
        g = df.groupby(col).agg(rev=("Revenue", "sum"), n=("Revenue", "size"), ticket=("Revenue", "mean")).reset_index()
        out[key] = [{"k": r[col], "rev": float(r.rev), "n": int(r.n), "ticket": float(r.ticket)} for _, r in g.iterrows()]
    b = df.groupby(["Brand", "Product_Category"]).Revenue.sum().reset_index().sort_values("Revenue", ascending=False)
    out["brands"] = [{"k": r.Brand, "cat": r.Product_Category, "rev": float(r.Revenue)} for _, r in b.iterrows()]
    out["holiday"] = {"rows": int(df.Holiday_Flag.sum()), "ticket_flag": float(df[df.Holiday_Flag == 1].Revenue.mean()),
                      "ticket_normal": float(df[df.Holiday_Flag == 0].Revenue.mean()),
                      "p": float(stats.ttest_ind(df[df.Holiday_Flag == 1].Revenue, df[df.Holiday_Flag == 0].Revenue).pvalue)}
    return out


def anomalies(daily: pd.Series, z=2.8) -> list:
    med = daily.rolling(29, center=True, min_periods=10).median()
    res = daily - med
    mad = np.median(np.abs(res - res.median())) * 1.4826
    sc = res / mad
    hit = sc[sc.abs() > z].sort_values(key=abs, ascending=False)
    return [{"date": d.strftime("%Y-%m-%d"), "value": float(daily[d]), "z": float(v)} for d, v in hit.head(12).items()]


def seasonality_profiles(daily: pd.Series) -> dict:
    dow = daily.groupby(daily.index.dayofweek).mean()
    mon = daily.groupby([daily.index.year, daily.index.month]).sum().unstack(0)
    return {"dow": (dow / dow.mean()).round(4).tolist(),
            "dow_p": float(stats.f_oneway(*[daily[daily.index.dayofweek == k] for k in range(7)]).pvalue)}


def kpis(df) -> dict:
    y = df.groupby("Year").agg(rev=("Revenue", "sum"), n=("Revenue", "size"), units=("Units_Sold", "sum"))
    return {"revenue": float(df.Revenue.sum()), "txns": int(len(df)), "units": int(df.Units_Sold.sum()),
            "ticket": float(df.Revenue.mean()), "growth": float(y.rev.get(2024) / y.rev.get(2023) - 1),
            "txn_growth": float(y.n.get(2024) / y.n.get(2023) - 1), "per_day": float(df.groupby("Date").Revenue.sum().mean())}
