"""Rule-based 'AI narrator': turns computed statistics into plain-English findings."""


def cr(x):  # rupees -> crore
    return f"\u20b9{x / 1e7:,.0f} Cr"


def cr1(x):
    return f"\u20b9{x / 1e7:,.1f} Cr"


def pv(p):
    return "p<0.001" if p < 0.001 else f"p={p:.2f}"


def build(k, disc, par, mix, seg, fc_total, quality, anoms, df):
    out = []
    cats = df.groupby("Product_Category").Revenue.sum().sort_values(ascending=False)
    top_c, low_c = cats.index[0], cats.index[-1]
    d = fc_total["diag"]
    st = sorted(seg["stores"], key=lambda s: -s["health"])
    gross_yr = disc["gross"] / 2
    save5 = gross_yr * 0.05
    ret = next(x for x in mix["customer"] if x["k"] == "Returning")
    new = next(x for x in mix["customer"] if x["k"] == "New")
    out.append({"tag": "Growth", "tone": "neutral", "title": f"{cr(k['revenue'])} net revenue, essentially flat year on year",
                "body": f"Revenue moved {k['growth']:+.1%} from 2023 to 2024 and transactions {k['txn_growth']:+.1%}. The business runs at "
                        f"{cr1(k['per_day'])} per day with a ticket of \u20b9{k['ticket'] / 1e5:,.2f} lakh. Growth must come from levers, not from momentum."})
    out.append({"tag": "Margin leak", "tone": "alert", "title": f"{cr(disc['leak'])} given away in discounts, with no volume to show for it",
                "body": f"Discounts removed {disc['leak_share']:.1%} of gross sales. Units per sale are the same at 0% and 20% off "
                        f"(ANOVA {pv(disc['p_units_anova'])}) and promotions do not change basket size ({pv(disc['p_promo'])}). "
                        f"Estimated volume change per extra discount point: {disc['lift_per_pp'] * 100:+.2f}% (95% CI \u00b1{disc['lift_ci'] * 100:.2f}%). "
                        f"Cutting the average discount by 5 points would be worth about {cr(save5)} per year if this holds."})
    out.append({"tag": "Forecastability", "tone": "warn", "title": f"Daily revenue is {d['verdict']}",
                "body": f"No weekday effect ({pv(d['weekday_p'])}), no month effect ({pv(d['month_p'])}), no trend ({pv(d['trend_p'])}) and no autocorrelation "
                        f"(Ljung-Box {pv(d['ljung_box_p'])}). {fc_total['champion_label']} won the backtest, so the forecast is a level with honest "
                        f"uncertainty bands rather than an invented seasonal wave."})
    out.append({"tag": "Stores", "tone": "neutral", "title": f"Eight stores within {seg['spread_pct']:.1f}% of each other",
                "body": f"Best health score: {st[0]['id']} {st[0]['city']} ({st[0]['health']:.0f}/100, {st[0]['growth']:+.1%} YoY). Lowest: {st[-1]['id']} {st[-1]['city']} "
                        f"({st[-1]['health']:.0f}/100). Basket value does not differ significantly across stores ({pv(seg['anova_p_ticket'])}), so the "
                        f"{seg['k']} archetypes describe small, relative differences, useful for ranking, not for alarm."})
    out.append({"tag": "Mix", "tone": "good", "title": f"Perfectly balanced portfolio: {top_c} leads, {low_c} trails by {(cats.iloc[0] - cats.iloc[-1]) / cats.mean():.1%}",
                "body": f"Five categories each hold {cats.min() / cats.sum():.1%} to {cats.max() / cats.sum():.1%} of revenue. The top 20% of SKU codes bring only "
                        f"{par['top20_share']:.0%} of revenue (Gini {par['gini']:.2f}) - there is no hero-product dependency and no long tail to prune."})
    out.append({"tag": "Customers", "tone": "neutral", "title": f"Returning customers are {ret['n'] / (ret['n'] + new['n']):.0%} of sales, spending the same as new ones",
                "body": f"Returning ticket \u20b9{ret['ticket'] / 1e5:,.2f} lakh vs new \u20b9{new['ticket'] / 1e5:,.2f} lakh. Loyalty brings repeat visits, not bigger baskets - a "
                        f"basket-building programme is the untested opportunity."})
    h = mix["holiday"]
    out.append({"tag": "Calendar", "tone": "warn", "title": "Holiday flag shows no uplift - and only exists in Oct-Dec",
                "body": f"{h['rows']} flagged rows average \u20b9{h['ticket_flag'] / 1e5:,.2f} lakh vs \u20b9{h['ticket_normal'] / 1e5:,.2f} lakh otherwise ({pv(h['p'])}). "
                        f"Because flags exist only for three months, festival demand (Diwali, Eid, Christmas, sales seasons) cannot be modelled from this file."})
    if anoms:
        a = anoms[0]
        out.append({"tag": "Anomaly", "tone": "alert", "title": f"{len(anoms)} unusual days flagged, led by {a['date']}",
                    "body": f"Robust z-score {a['z']:+.1f} against a 29-day rolling median (revenue {cr1(a['value'])}). With ~100 sales a day, a few extreme "
                            f"days are expected by chance; investigate before assuming a cause."})
    warn = [q for q in quality if q["status"] != "pass"]
    if warn:
        out.append({"tag": "Data", "tone": "warn", "title": f"{len(warn)} data caveats worth stating in your report",
                    "body": " ".join(q["name"] + ": " + q["detail"] + "." for q in warn)})
    return out
