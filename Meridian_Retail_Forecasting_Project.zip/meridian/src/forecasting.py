"""Forecast arena: 7 candidate models, rolling-origin backtest, champion selection,
empirical prediction intervals and a forecastability diagnosis."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

from .config import BACKTEST_FOLDS, BACKTEST_H, HORIZON_DAYS, SEED

MODEL_LABELS = {
    "mean_all": "Long-run mean", "mean_28": "Trailing 28-day mean", "snaive_7": "Seasonal naive (weekly)",
    "ets_week": "Holt-Winters (weekly)", "ridge_cal": "Ridge on Fourier calendar",
    "gbm_cal": "Gradient boosting calendar", "blend": "Blend (mean + ETS + Ridge)",
}


# ------------------------------------------------------------------ features
def _calendar(idx: pd.DatetimeIndex, t0: pd.Timestamp, fourier=True):
    t = (idx - t0).days.values.astype(float)
    if fourier:
        cols = [t / 365.0]
        for k in (1, 2, 3):
            cols += [np.sin(2 * np.pi * k * t / 7), np.cos(2 * np.pi * k * t / 7)]
        for k in (1, 2, 3):
            cols += [np.sin(2 * np.pi * k * t / 365.25), np.cos(2 * np.pi * k * t / 365.25)]
        return np.column_stack(cols)
    return np.column_stack([t, idx.dayofweek, idx.day, idx.month, idx.dayofyear, idx.is_month_end.astype(int)])


# ------------------------------------------------------------------ models
def _ets(y, h, m=7):
    y = np.asarray(y, float)
    n = len(y)

    def run(p, forecast=False):
        a, g = p
        lvl = y[:m].mean()
        s = np.zeros(n + m)
        s[:m] = y[:m] - lvl
        sse = 0.0
        for i in range(m, n):
            e = y[i] - (lvl + s[i - m])
            lvl += a * e
            s[i] = s[i - m] + g * e
            sse += e * e
        if forecast:
            return np.array([lvl + s[n - m + (j % m)] for j in range(h)])
        return sse

    res = minimize(run, [0.05, 0.05], bounds=[(0.001, 0.5), (0.001, 0.5)], method="L-BFGS-B")
    return run(res.x, True)


def _predict(name, train: pd.Series, h: int) -> np.ndarray:
    fidx = pd.date_range(train.index[-1] + pd.Timedelta(days=1), periods=h)
    y = train.values
    if name == "mean_all":
        return np.full(h, y.mean())
    if name == "mean_28":
        return np.full(h, y[-28:].mean())
    if name == "snaive_7":
        return np.array([y[-7 + (j % 7)] for j in range(h)])
    if name == "ets_week":
        return _ets(y, h)
    if name == "ridge_cal":
        t0 = train.index[0]
        sc = StandardScaler().fit(_calendar(train.index, t0))
        mdl = Ridge(alpha=30.0).fit(sc.transform(_calendar(train.index, t0)), y)
        return mdl.predict(sc.transform(_calendar(fidx, t0)))
    if name == "gbm_cal":
        t0 = train.index[0]
        mdl = GradientBoostingRegressor(n_estimators=120, max_depth=2, learning_rate=0.05,
                                        subsample=0.8, random_state=SEED)
        mdl.fit(_calendar(train.index, t0, False), y)
        return mdl.predict(_calendar(fidx, t0, False))
    if name == "blend":
        return np.mean([_predict(k, train, h) for k in ("mean_all", "ets_week", "ridge_cal")], axis=0)
    raise KeyError(name)


# ------------------------------------------------------------------ diagnostics
def forecastability(y: pd.Series) -> dict:
    """Is there anything to forecast beyond a flat level?"""
    v = y.values.astype(float)
    n = len(v)
    d = v - v.mean()
    ac = np.array([np.sum(d[k:] * d[:-k]) / np.sum(d * d) for k in range(1, 15)])
    lb = n * (n + 2) * np.sum(ac ** 2 / (n - np.arange(1, 15)))
    p_lb = float(1 - stats.chi2.cdf(lb, 14))
    dow = [v[y.index.dayofweek == k] for k in range(7)]
    p_dow = float(stats.f_oneway(*dow).pvalue)
    mon = [v[y.index.month == k] for k in range(1, 13)]
    p_mon = float(stats.f_oneway(*mon).pvalue)
    p_trend = float(stats.linregress(np.arange(n), v).pvalue)
    cv = float(v.std() / v.mean())
    # structure score: 0 = every test says "noise", 100 = every test is extremely significant
    score = int(round(100 * np.mean([0 if p >= 0.05 else 1 - p / 0.05 for p in (p_lb, p_dow, p_mon, p_trend)])))
    verdict = ("strong structure" if score >= 60 else "some structure" if score >= 25 else
               "close to pure noise around a level")
    return {"ljung_box_p": p_lb, "weekday_p": p_dow, "month_p": p_mon, "trend_p": p_trend,
            "lag1_autocorr": float(ac[0]), "cv": cv, "score": score, "verdict": verdict}


# ------------------------------------------------------------------ arena
def run_arena(y: pd.Series, horizon=HORIZON_DAYS, h=BACKTEST_H, folds=BACKTEST_FOLDS) -> dict:
    y = y.asfreq("D")
    n = len(y)
    first = n - h - (folds - 1) * h
    names = list(MODEL_LABELS)
    errs = {m: [] for m in names}
    curve = {"date": [], "actual": [], "pred": {m: [] for m in names}}
    for f in range(folds):
        o = first + f * h
        tr, te = y.iloc[:o], y.iloc[o:o + h]
        for m in names:
            p = _predict(m, tr, h)
            errs[m].append(te.values - p)
            curve["pred"][m].extend(p.tolist())
        curve["date"].extend([d.strftime("%Y-%m-%d") for d in te.index])
        curve["actual"].extend(te.values.tolist())
    board = []
    base_mae = float(np.mean(np.abs(np.concatenate(errs["mean_all"]))))
    for m in names:
        e = np.concatenate(errs[m])
        a = np.array(curve["actual"])
        fold_mae = [float(np.mean(np.abs(x))) for x in errs[m]]
        base_fold = [float(np.mean(np.abs(x))) for x in errs["mean_all"]]
        board.append({
            "model": m, "label": MODEL_LABELS[m],
            "mae": float(np.mean(np.abs(e))), "rmse": float(np.sqrt(np.mean(e ** 2))),
            "mape": float(np.mean(np.abs(e) / a) * 100), "bias": float(np.mean(e)),
            "skill": float(1 - np.mean(np.abs(e)) / base_mae),
            "win_rate": float(np.mean([a_ < b_ for a_, b_ in zip(fold_mae, base_fold)])),
        })
    board.sort(key=lambda r: r["mae"])
    champ = board[0]["model"]
    resid = np.concatenate(errs[champ])
    fut = _predict(champ, y, horizon)
    fidx = pd.date_range(y.index[-1] + pd.Timedelta(days=1), periods=horizon)
    q = {k: float(np.quantile(resid, v)) for k, v in
         {"lo95": .025, "lo80": .10, "hi80": .90, "hi95": .975}.items()}
    rng = np.random.default_rng(SEED)
    months = []
    for per, grp in pd.Series(fut, index=fidx).groupby(fidx.to_period("M")):
        sims = grp.sum() + rng.choice(resid, size=(3000, len(grp))).sum(axis=1)
        months.append({"month": str(per), "days": int(len(grp)), "point": float(grp.sum()),
                       "lo95": float(np.quantile(sims, .025)), "lo80": float(np.quantile(sims, .10)),
                       "hi80": float(np.quantile(sims, .90)), "hi95": float(np.quantile(sims, .975))})
    return {
        "board": board, "champion": champ, "champion_label": MODEL_LABELS[champ],
        "history_tail": {"date": [d.strftime("%Y-%m-%d") for d in y.index[-120:]], "value": y.values[-120:].tolist()},
        "forecast": {"date": [d.strftime("%Y-%m-%d") for d in fidx], "point": fut.tolist(),
                     "lo95": (fut + q["lo95"]).tolist(), "lo80": (fut + q["lo80"]).tolist(),
                     "hi80": (fut + q["hi80"]).tolist(), "hi95": (fut + q["hi95"]).tolist()},
        "months": months,
        "backtest": {"date": curve["date"], "actual": curve["actual"], "pred": curve["pred"][champ],
                     "baseline": curve["pred"]["mean_all"]},
        "diag": forecastability(y),
        "level": float(y.mean()),
    }
