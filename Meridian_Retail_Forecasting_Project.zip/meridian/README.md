# Meridian — Retail Intelligence Observatory
**Retail Analytics & AI-Powered Sales Forecasting System** · Unlox Major Project · dataset: 73,000 sales, Jan 2023 – Dec 2024, 8 stores, 5 categories

Meridian is an end-to-end decision-support tool: a Python analytics pipeline that cleans and tests the data, runs a forecast "arena", segments the stores, and writes a self-contained interactive dashboard that works fully **offline**.

## Run it (2 minutes)
```bash
pip install -r requirements.txt        # pandas, numpy, scipy, scikit-learn, openpyxl
python run.py                          # builds if needed, serves the dashboard, opens your browser
```
* The dashboard is **pre-built**: you can also just double-click `web/index.html` (no server needed).
* `python run.py --rebuild` re-runs the whole pipeline (~20 s). `python run.py --data path/to/file.xlsx` works with the original CSV or XLSX.
* Python 3.9+. Fonts load from Google Fonts when online and fall back to system fonts offline.

## What is in the box
| Path | Purpose |
|---|---|
| `run.py` | One-command launcher |
| `src/etl.py` | Loads CSV/XLSX (handles both date formats), 12 integrity checks, derived columns |
| `src/analytics.py` | Aggregation cubes, discount economics (ANOVA, elasticity), SKU Pareto, anomaly detection |
| `src/forecasting.py` | 7-model forecast arena, rolling-origin backtest, champion selection, empirical intervals, forecastability tests |
| `src/segmentation.py` | 11 store features → KMeans (k by silhouette) → PCA, archetypes, health score |
| `src/insights.py` | Rule-based "AI narrator" that turns statistics into plain-English findings |
| `src/report.py`, `src/build.py` | Auto-writes `outputs/REPORT.md` and the dashboard data |
| `web/` | `index.html`, `style.css`, `app.js` (zero-dependency hand-built SVG charts), `data.js` (generated) |
| `outputs/` | `REPORT.md`, `forecast_daily.csv`, `model_leaderboard.csv`, `store_segments.csv`, `data_quality_report.csv` |

## Mapping to the project objectives
| Objective in the brief | Where it lives |
|---|---|
| Analyse sales across stores & categories | Dashboard §02 Pulse, §03 Mix (sunburst, brand league, customers, payments) |
| Sales patterns, growth drivers, seasonality | Pulse: YoY, calendar heatmap, weekday/month deviation + significance tests; Discount Lab |
| Forecast revenue with time-series modelling | §05 Forecast: 7 models, 11-fold backtest, 181-day forecast with 80/95% bands, per category and per store |
| Segment stores by performance & behaviour | §04 Stores: KMeans constellation map, radar, health score |
| Interactive AI dashboard | Filters, "Ask Meridian" natural-language query box, auto-generated brief, what-if simulator |

## What makes it different
1. **It tests whether forecasting is even possible.** Ljung-Box, weekday/month ANOVA and a trend test give a *forecastability score* before any model is trusted.
2. **Honest model arena.** Models must beat the long-run mean on rolling folds; otherwise the flat level with intervals is the answer, not a decorative seasonal wave.
3. **Discount Lab.** Quantifies the ₹457 Cr of discounts and the volume response (≈0), with a break-even simulator.
4. **Ask Meridian.** Type "best store in Q4 2024", "forecast for Electronics", "average ticket by store"…
5. **Zero-dependency front end**: every chart is hand-drawn SVG, no chart library.

## Key findings (full numbers in `outputs/REPORT.md`)
* ₹4,113 Cr net revenue; 2024 vs 2023 is −0.7%.
* Discounts remove 10% of gross sales (₹457 Cr) with no measurable volume lift (ANOVA p = 0.66).
* Daily revenue behaves like noise around ₹5.6 Cr/day — no weekday, month or trend structure; the long-run mean wins the backtest.
* Stores are within 3.5% of each other; categories each hold ~20% of revenue.
* Data caveats: `Product_ID` maps to several categories/brands; `Holiday_Flag` exists only for Oct–Dec.

## Likely viva questions
* **Why is the forecast flat?** Because the tests show no structure, and every seasonal model scored worse than the mean in backtesting. Forcing a wave would be overfitting.
* **How were models validated?** Rolling-origin backtest: 11 folds, each trained on the past and tested on the next 30 days.
* **How are the intervals built?** Empirical quantiles of the champion's backtest errors; monthly intervals by bootstrap-summing those errors.
* **How was k chosen for the stores?** Silhouette score over k = 2…4; the stores are similar, so segments are relative rankings.
* **What would you do with better data?** Add promotion calendars, festival dates, pricing and footfall, then re-run `python run.py` — the arena will promote a seasonal or ML model automatically if it earns it.

## Submission checklist (deadline 15/10/2026, via LMS)
- [ ] Zip this folder (or the same structure) · [ ] include `outputs/REPORT.md` · [ ] 3-minute screen recording of the dashboard · [ ] follow the LMS guidelines exactly
