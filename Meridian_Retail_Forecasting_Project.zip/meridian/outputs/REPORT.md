# Meridian - Retail Analytics & AI-Powered Sales Forecasting System

*Auto-generated 09 Oct 2026, 11:02 from `Retail_Sales_Data_Unlox.csv` (73,000 rows, 2023-01-01 to 2024-12-31).*

## 1. Executive summary

- **₹4,113 Cr net revenue, essentially flat year on year.** Revenue moved -0.7% from 2023 to 2024 and transactions -0.4%. The business runs at ₹5.6 Cr per day with a ticket of ₹5.63 lakh. Growth must come from levers, not from momentum.
- **₹457 Cr given away in discounts, with no volume to show for it.** Discounts removed 10.0% of gross sales. Units per sale are the same at 0% and 20% off (ANOVA p=0.66) and promotions do not change basket size (p=0.87). Estimated volume change per extra discount point: -0.04% (95% CI ±0.09%). Cutting the average discount by 5 points would be worth about ₹114 Cr per year if this holds.
- **Daily revenue is close to pure noise around a level.** No weekday effect (p=0.44), no month effect (p=0.96), no trend (p=0.37) and no autocorrelation (Ljung-Box p=0.65). Long-run mean won the backtest, so the forecast is a level with honest uncertainty bands rather than an invented seasonal wave.
- **Eight stores within 3.5% of each other.** Best health score: STR_102 Bangalore (81/100, +3.7% YoY). Lowest: STR_105 Pune (35/100). Basket value does not differ significantly across stores (p=0.45), so the 4 archetypes describe small, relative differences, useful for ranking, not for alarm.
- **Perfectly balanced portfolio: Electronics leads, Sports trails by 1.9%.** Five categories each hold 19.9% to 20.2% of revenue. The top 20% of SKU codes bring only 25% of revenue (Gini 0.09) - there is no hero-product dependency and no long tail to prune.
- **Returning customers are 60% of sales, spending the same as new ones.** Returning ticket ₹5.63 lakh vs new ₹5.65 lakh. Loyalty brings repeat visits, not bigger baskets - a basket-building programme is the untested opportunity.
- **Holiday flag shows no uplift - and only exists in Oct-Dec.** 897 flagged rows average ₹5.49 lakh vs ₹5.64 lakh otherwise (p=0.39). Because flags exist only for three months, festival demand (Diwali, Eid, Christmas, sales seasons) cannot be modelled from this file.
- **12 unusual days flagged, led by 2023-12-14.** Robust z-score +3.9 against a 29-day rolling median (revenue ₹8.0 Cr). With ~100 sales a day, a few extreme days are expected by chance; investigate before assuming a cause.
- **2 data caveats worth stating in your report.** Product_ID maps to one category: each Product_ID appears under up to 5 categories and 20 brands - so it is treated as a SKU code, and merchandising is analysed at Brand / Subcategory level. Holiday_Flag coverage: flag only appears in months [10, 11, 12]; holiday uplift cannot be learned for other months.

## 2. Data & quality

| Check | Status | Detail |
|---|---|---|
| Row count | PASS | 73,000 rows x 19 columns |
| Missing values | PASS | 0 missing cells |
| Duplicate rows | PASS | 0 exact duplicates |
| Calendar coverage | PASS | 01 Jan 2023 to 31 Dec 2024, 731 days, 0 days without sales |
| Total_Sales = Unit_Price x Units_Sold | PASS | max abs difference 4.66e-10 |
| Revenue = Total_Sales x (1 - Discount%) | PASS | max abs difference 6.98e-10 |
| Store -> City -> Region is 1:1 | PASS | 8 stores, 4 regions |
| Units sold never exceed stock on hand | PASS | 0.00% rows violate |
| Product_ID maps to one category | WARN | each Product_ID appears under up to 5 categories and 20 brands - so it is treated as a SKU code, and merchandising is analysed at Brand / Subcategory level |
| Brand -> Category is unique | PASS | max categories per brand = 1 |
| Rating range | PASS | 3.5 to 5.0 |
| Extreme revenue outliers (3xIQR) | PASS | 0.00% of rows |
| Holiday_Flag coverage | WARN | flag only appears in months [10, 11, 12]; holiday uplift cannot be learned for other months |

## 3. Forecasting

Seven models were compared with a rolling-origin backtest (11 folds x 30 days). Champion for total revenue: **Long-run mean**.

| Model | MAE (₹ Cr/day) | MAPE | Skill vs long-run mean | Fold win-rate |
|---|---|---|---|---|
| Long-run mean | 0.576 | 10.6% | +0.0% | 0% |
| Blend (mean + ETS + Ridge) | 0.576 | 10.5% | -0.0% | 55% |
| Ridge on Fourier calendar | 0.579 | 10.5% | -0.5% | 45% |
| Trailing 28-day mean | 0.580 | 10.6% | -0.7% | 36% |
| Holt-Winters (weekly) | 0.581 | 10.6% | -0.8% | 45% |
| Gradient boosting calendar | 0.630 | 11.3% | -9.4% | 27% |
| Seasonal naive (weekly) | 0.796 | 14.4% | -38.3% | 0% |

Forecastability tests: Ljung-Box p=0.65, weekday ANOVA p=0.44, month ANOVA p=0.96, trend p=0.37 -> structure score 0/100 (*close to pure noise around a level*).

Next six months (80% interval from backtest residuals):

| Month | Forecast | 80% low | 80% high |
|---|---|---|---|
| 2025-01 | ₹174 Cr | ₹169 Cr | ₹179 Cr |
| 2025-02 | ₹158 Cr | ₹152 Cr | ₹162 Cr |
| 2025-03 | ₹174 Cr | ₹169 Cr | ₹179 Cr |
| 2025-04 | ₹169 Cr | ₹163 Cr | ₹173 Cr |
| 2025-05 | ₹174 Cr | ₹169 Cr | ₹179 Cr |
| 2025-06 | ₹169 Cr | ₹163 Cr | ₹173 Cr |

## 4. Store segmentation

KMeans on 11 standardised behavioural features; k=4 chosen by silhouette (0.23).

| Store | City | Archetype | Health | Revenue | YoY |
|---|---|---|---|---|---|
| STR_102 | Bangalore | Rising Star | 81 | ₹519 Cr | +3.7% |
| STR_103 | Delhi | Full-Price Faithful | 65 | ₹522 Cr | -2.3% |
| STR_107 | Kolkata | Softer Ratings | 52 | ₹511 Cr | +0.9% |
| STR_108 | Ahmedabad | Lighter Volume | 50 | ₹508 Cr | -0.3% |
| STR_101 | Mumbai | Full-Price Faithful | 48 | ₹517 Cr | -2.1% |
| STR_104 | Chennai | Full-Price Faithful | 44 | ₹517 Cr | -2.1% |
| STR_106 | Hyderabad | Lighter Volume | 42 | ₹504 Cr | -1.5% |
| STR_105 | Pune | Softer Ratings | 35 | ₹516 Cr | -1.8% |

## 5. Discount economics

| Discount | Transactions | Avg units | Avg ticket (₹) |
|---|---|---|---|
| 0% | 14,560 | 24.91 | 627,932 |
| 5% | 14,556 | 24.90 | 592,092 |
| 10% | 14,600 | 24.82 | 562,984 |
| 15% | 14,740 | 25.03 | 535,915 |
| 20% | 14,544 | 24.80 | 498,737 |

## 6. Recommendations

1. Pilot a smaller discount ladder (cap at 10%) in two stores and measure units/basket; the history shows no volume reward for deeper cuts.
2. Add festival and promotion calendars to the data - the current Holiday_Flag covers only Oct-Dec and cannot support demand planning.
3. Fix the SKU master: Product_ID currently maps to multiple categories and brands.
4. Test basket-building offers for returning customers; ticket size is identical to new customers.
5. Re-run `python run.py` monthly. If seasonality emerges, the arena will automatically promote a seasonal model.
